create definer = root@localhost view v_emp as
select `emp_ms`.`employee`.`id`      AS `id`,
       `emp_ms`.`employee`.`name`    AS `name`,
       `emp_ms`.`employee`.`passwd`  AS `passwd`,
       `emp_ms`.`employee`.`sex`     AS `sex`,
       `emp_ms`.`employee`.`rate`    AS `rate`,
       `emp_ms`.`employee`.`birth`   AS `birth`,
       `emp_ms`.`employee`.`address` AS `address`,
       `emp_ms`.`employee`.`cardId`  AS `cardId`,
       `emp_ms`.`employee`.`tel`     AS `tel`,
       `emp_ms`.`employee`.`dep_id`  AS `dep_id`,
       `emp_ms`.`employee`.`job_id`  AS `job_id`
from `emp_ms`.`employee`
where (concat(`emp_ms`.`employee`.`name`, '@localhost') = user());

