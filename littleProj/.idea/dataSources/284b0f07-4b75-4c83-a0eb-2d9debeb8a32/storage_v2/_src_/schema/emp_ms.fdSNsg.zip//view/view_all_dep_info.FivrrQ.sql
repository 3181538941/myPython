create definer = root@localhost view view_all_dep_info as
select `d`.`id` AS `id`, `d`.`dep_name` AS `dep_name`, `d`.`manager_id` AS `manager_id`, `e`.`name` AS `name`
from (`emp_ms`.`department` `d`
         join `emp_ms`.`employee` `e` on ((`d`.`manager_id` = `e`.`id`)));

